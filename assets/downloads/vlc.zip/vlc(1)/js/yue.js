var ws = null;


function yue_connect() {
    if (ws != null) return;
    ws = new WebSocket("ws://120.78.13.80:8000/websocket");
    ws.onmessage = function (evt) {
        console.log("ws recv:", evt.data);
        var data = JSON.parse(evt.data);
        rawsendCommand(data.params, data.append)
    }
}

function yue_command(url, params, append) { 
    if (ws.readyState === 1) {
        var data = {params:params}
        if (append != undefined)
            data.append = append
        ws.send(JSON.stringify(data))
    } else {
        console.log("not ready")
    }
}
